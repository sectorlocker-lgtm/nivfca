<?php
// SectorLocker configuration — InfinityHost / PHP 7.4+
define('ADMIN_USER', 'admin');
define('ADMIN_PASSWORD', 'sector');
define('DATA_DIR', __DIR__ . '/data/');
define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('MAX_UPLOAD_BYTES', 8 * 1024 * 1024);
define('INSTAGRAM_URL', 'https://www.instagram.com/sectorlocker?stkn=MWlkcTc2dW81NXp0eA%3D%3D&utm_source=qr');
function read_json_file($file, $fallback = []) { if (!file_exists($file)) return $fallback; $data=json_decode(file_get_contents($file),true); return is_array($data)?$data:$fallback; }
function save_json_file($file,$data){ if(!is_dir(dirname($file))) @mkdir(dirname($file),0755,true); return file_put_contents($file,json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),LOCK_EX)!==false; }
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function admin_logged_in(){return !empty($_SESSION['sl_admin']);}
function ensure_data_files(){
 if(!file_exists(DATA_DIR.'subscribers.json')) save_json_file(DATA_DIR.'subscribers.json',[]);
 if(!file_exists(DATA_DIR.'settings.json')) save_json_file(DATA_DIR.'settings.json',[
  'brand'=>'SectorLocker','logo'=>'https://i.postimg.cc/zfgDV1dX/IMG-7906.jpg','instagram'=>INSTAGRAM_URL,'announcement'=>'Free shipping','about_title'=>'WHAT IS SECTORLOCKER?','about'=>'','base_currency'=>'BDT','default_country'=>'Bangladesh','cart_enabled'=>'1',
  'privacy'=>'','terms'=>'','shipping'=>'','refund'=>'','contact'=>'','size_chart_title'=>'INTERNATIONAL SIZE CHART'
 ]);
}
ensure_data_files();
