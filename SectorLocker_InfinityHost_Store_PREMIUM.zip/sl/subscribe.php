<?php
require __DIR__.'/config.php';
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['ok'=>false]); exit; }
$email = strtolower(trim($_POST['email'] ?? ''));
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { http_response_code(422); echo json_encode(['ok'=>false,'message'=>'Please enter a valid email.']); exit; }
$file = DATA_DIR.'subscribers.json';
$list = read_json_file($file, []);
foreach ($list as $item) if (strtolower($item['email'] ?? '') === $email) { echo json_encode(['ok'=>true,'message'=>'You are already subscribed.']); exit; }
$list[] = ['email'=>$email,'date'=>date('c')];
save_json_file($file,$list);
echo json_encode(['ok'=>true,'message'=>'Thanks — you are on the list.']);
