SECTORLOCKER — INFINITYHOST UPLOAD

1. Upload ALL files and folders inside this ZIP into your InfinityHost public_html / htdocs folder.
2. Make sure these folders are writable by PHP:
   - data/
   - uploads/
3. Open your domain.
4. Admin panel: https://YOUR-DOMAIN/admin.php

ADMIN LOGIN
Username: admin
Password: sector

MAIN FEATURES
- Premium black/white SectorLocker storefront.
- Small brand logo in the header and footer.
- HOME / ABOUT / SOCIAL navigation. Admin is not shown in the public menu.
- Product click opens a 2-second rolling product animation before the premium product page.
- Product page includes size selection, stock-aware quantities, Size Chart and Add to Cart.
- Cart is active and stored in the customer's browser.
- Instagram ordering button uses the SectorLocker Instagram URL.
- Base price currency is ALWAYS BDT. Bangladesh is the default country/region.
- Customers can change country/region and prices automatically convert from BDT using a live exchange-rate service when available.
- Google Pay, Apple Pay, Visa, Mastercard, AMEX, PayPal, bKash and Nagad are displayed as payment methods. These are display badges; connecting real payment gateways requires separate merchant/API credentials.
- Email subscriptions are saved to data/subscribers.json and shown in Admin Panel.

ADMIN PANEL
- Store overview/dashboard.
- Edit brand name, logo URL, Instagram URL, announcement and About content.
- Edit Privacy Policy, Terms of Service, Shipping Policy, Refund Policy and Contact Information.
- Edit the Size Chart text.
- Add, edit, hide/show and delete products.
- Upload product images.
- Set BDT price and old BDT price.
- Turn SALE badge on/off.
- Edit S / M / L / XL / XXL stock separately.
- View and delete email subscribers.

IMPORTANT
- Product prices are stored in BDT. Edit them in Admin Panel under Price (BDT).
- Real Google Pay/bKash/Nagad payments are NOT activated by this package. The visible payment badges are for storefront presentation only. To accept live payments, add the official merchant credentials/API integration for your payment provider.
- If live currency conversion is unavailable, the site falls back to the BDT base amount.
