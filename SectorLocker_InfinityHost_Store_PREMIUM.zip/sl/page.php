<?php
require __DIR__.'/config.php';
$settings=read_json_file(DATA_DIR.'settings.json',[]);
$slug=$_GET['slug']??'privacy';
$map=['privacy'=>['Privacy Policy','privacy'],'terms'=>['Terms of Service','terms'],'shipping'=>['Shipping Policy','shipping'],'refund'=>['Refund Policy','refund'],'contact'=>['Contact Information','contact']];
if(!isset($map[$slug])){$slug='privacy';}
[$title,$key]=$map[$slug];$content=$settings[$key]??'';
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($title)?> · <?=e($settings['brand']??'SectorLocker')?></title><link rel="stylesheet" href="assets/style.css"></head><body class="legal-page"><header class="site-header compact-header"><a class="back-link" href="index.php">←</a><a class="logo-wrap tiny-logo" href="index.php"><img src="<?=e($settings['logo']??'')?>" alt="Logo"></a><a class="text-link" href="index.php">SHOP</a></header><main class="legal-main"><p class="eyebrow">SECTORLOCKER</p><h1><?=e($title)?></h1><div class="legal-copy"><?php foreach(preg_split("/\n\s*\n/",trim($content)) as $p):?><p><?=nl2br(e($p))?></p><?php endforeach;?></div></main></body></html>
